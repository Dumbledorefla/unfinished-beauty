ALTER TABLE `users` ADD `fullName` text;--> statement-breakpoint
ALTER TABLE `users` ADD `birthDate` date;