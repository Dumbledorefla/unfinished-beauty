import * as esbuild from "esbuild";

await esbuild.build({
  entryPoints: ["server/_core/index.ts"],
  bundle: true,
  platform: "node",
  target: "node20",
  outfile: "dist/index.js",
  format: "esm",
  sourcemap: true,
  minify: false,
  // Exclude Vite and its dependencies (only used in dev mode)
  // Also exclude all native .node files and problematic packages
  external: [
    // Vite and dev-only dependencies
    "vite",
    "lightningcss",
    "@tailwindcss/*",
    "@babel/*",
    "@vitejs/*",
    "@builder.io/*",
    "vite-plugin-manus-runtime",
    // Native Node.js modules
    "crypto",
    "fs",
    "fs/promises",
    "path",
    "http",
    "https",
    "net",
    "os",
    "stream",
    "url",
    "util",
    "zlib",
    "events",
    "buffer",
    "querystring",
    "child_process",
    "tls",
    "dns",
    "dgram",
    "cluster",
    "worker_threads",
    "perf_hooks",
    "async_hooks",
    "string_decoder",
    "readline",
    "assert",
    "constants",
    "timers",
    "tty",
    "v8",
    "vm",
    "inspector",
    // Node.js prefixed modules
    "node:crypto",
    "node:fs",
    "node:path",
    "node:http",
    "node:https",
    "node:net",
    "node:os",
    "node:stream",
    "node:url",
    "node:util",
    "node:zlib",
    "node:events",
    "node:buffer",
    "node:querystring",
    "node:child_process",
    "node:tls",
    "node:dns",
    "node:dgram",
    "node:cluster",
    "node:worker_threads",
    "node:perf_hooks",
    "node:async_hooks",
    "node:string_decoder",
    "node:readline",
    "node:assert",
    "node:constants",
    "node:timers",
    "node:tty",
    "node:v8",
    "node:vm",
    "node:inspector",
  ],
  loader: {
    ".node": "empty",
  },
  banner: {
    js: `
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const require = createRequire(import.meta.url);
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
`,
  },
  define: {
    "import.meta.dirname": "__dirname",
  },
});

console.log("Backend build complete: dist/index.js");
