import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

describe("build configuration", () => {
  it("should have esbuild config file", () => {
    const configPath = path.resolve(__dirname, "../esbuild.config.mjs");
    expect(fs.existsSync(configPath)).toBe(true);
  });

  it("should have correct build script in package.json", () => {
    const pkgPath = path.resolve(__dirname, "../package.json");
    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
    
    // Build should compile both client and server
    expect(pkg.scripts.build).toContain("vite build");
    expect(pkg.scripts.build).toContain("esbuild.config.mjs");
  });

  it("should have correct start script in package.json", () => {
    const pkgPath = path.resolve(__dirname, "../package.json");
    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
    
    // Start should run the compiled server
    expect(pkg.scripts.start).toContain("node dist/index.js");
    expect(pkg.scripts.start).toContain("NODE_ENV=production");
  });

  it("should have server entry point", () => {
    const entryPath = path.resolve(__dirname, "_core/index.ts");
    expect(fs.existsSync(entryPath)).toBe(true);
  });

  it("should have vercel.json with API routes", () => {
    const vercelPath = path.resolve(__dirname, "../vercel.json");
    const vercelConfig = JSON.parse(fs.readFileSync(vercelPath, "utf-8"));
    
    expect(vercelConfig.buildCommand).toBe("pnpm build");
    expect(vercelConfig.routes).toBeDefined();
    expect(Array.isArray(vercelConfig.routes)).toBe(true);
  });

  it("should serve static files in production mode", () => {
    // Verify the vite.ts has serveStatic function
    const vitePath = path.resolve(__dirname, "_core/vite.ts");
    const viteContent = fs.readFileSync(vitePath, "utf-8");
    
    expect(viteContent).toContain("serveStatic");
    expect(viteContent).toContain("express.static");
    expect(viteContent).toContain("index.html");
  });

  it("should have tRPC middleware configured", () => {
    const indexPath = path.resolve(__dirname, "_core/index.ts");
    const indexContent = fs.readFileSync(indexPath, "utf-8");
    
    expect(indexContent).toContain("/api/trpc");
    expect(indexContent).toContain("createExpressMiddleware");
    expect(indexContent).toContain("appRouter");
    expect(indexContent).toContain("createContext");
  });

  it("should conditionally use Vite in dev and static in production", () => {
    const indexPath = path.resolve(__dirname, "_core/index.ts");
    const indexContent = fs.readFileSync(indexPath, "utf-8");
    
    expect(indexContent).toContain('process.env.NODE_ENV === "development"');
    expect(indexContent).toContain("setupVite");
    expect(indexContent).toContain("serveStatic");
  });
});
